package Ts3querrybot;

import java.util.*;
import java.util.logging.Level;
import com.github.theholywaffle.teamspeak3.TS3Api;
import com.github.theholywaffle.teamspeak3.TS3Config;
import com.github.theholywaffle.teamspeak3.TS3Query;
import com.github.theholywaffle.teamspeak3.TS3Query.FloodRate;

import Load.Event;

public class Load {

    public static TS3Config config = new TS3Config();
    public static TS3Query query = new TS3Query(config);
    public static TS3Api api = new TS3Api(query);
    public static final String ip = "160.20.145.17";

    public static ArrayList<String>onlinesups = new ArrayList<String>();
    public static ArrayList<String>onlinesofware = new ArrayList<String>();
    public static ArrayList<String>onlinehardware = new ArrayList<String>();
    public static ArrayList<String>onlinecamera = new ArrayList<String>();
    public static Date date = new Date();

    public static void main(String[] args) {
        config.setHost(ip);
        config.setFloodRate(FloodRate.UNLIMITED);
        config.setDebugLevel(Level.ALL);
        config.setQueryPort(10011);
        query.connect();

        api.login("Supportbot","");
        api.selectVirtualServerByPort(9987);
        //api.selectVirtualServerById(714);

        api.setNickname("SupportBot");
        //MySQL.connect();
        Event.loadEvents();

        System.out.println("Bot gestartet");
    }
}