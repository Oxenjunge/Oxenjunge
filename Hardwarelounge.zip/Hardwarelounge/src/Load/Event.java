package Load;

import com.github.theholywaffle.teamspeak3.TS3Api;
import com.github.theholywaffle.teamspeak3.api.ChannelProperty;
import com.github.theholywaffle.teamspeak3.api.event.ChannelCreateEvent;
import com.github.theholywaffle.teamspeak3.api.event.ChannelDeletedEvent;
import com.github.theholywaffle.teamspeak3.api.event.ChannelDescriptionEditedEvent;
import com.github.theholywaffle.teamspeak3.api.event.ChannelEditedEvent;
import com.github.theholywaffle.teamspeak3.api.event.ChannelMovedEvent;
import com.github.theholywaffle.teamspeak3.api.event.ChannelPasswordChangedEvent;
import com.github.theholywaffle.teamspeak3.api.event.ClientJoinEvent;
import com.github.theholywaffle.teamspeak3.api.event.ClientLeaveEvent;
import com.github.theholywaffle.teamspeak3.api.event.ClientMovedEvent;
import com.github.theholywaffle.teamspeak3.api.event.PrivilegeKeyUsedEvent;
import com.github.theholywaffle.teamspeak3.api.event.ServerEditedEvent;
import com.github.theholywaffle.teamspeak3.api.event.TS3Listener;
import com.github.theholywaffle.teamspeak3.api.event.TextMessageEvent;
import com.github.theholywaffle.teamspeak3.api.wrapper.Client;

import Ts3querrybot.Load;

import java.util.HashMap;
import java.util.Map;
import java.util.*;

public class Event {
    
    public static Load load = new Load();
    public static TS3Api api = Load.api;
    public static HashMap<Integer, String> move = new HashMap<Integer, String>();
    public static HashMap<Integer, Boolean> moveable = new HashMap<Integer, Boolean>();
		
	

    public static void loadEvents() {
        Load.api.registerAllEvents();
        Load.api.addTS3Listeners(new TS3Listener() {

            @Override
            public void onTextMessage(TextMessageEvent e) {
            	Client c = Load.api.getClientInfo(e.getInvokerId());
                if(e.getMessage().equalsIgnoreCase("!move")) {
                    if(move.containsKey(c.getId())) {
                        if(move.get(c.getId()) == "hardware" && moveable.get(c.getId()) == true) {
                            if(c.getChannelId() == 17) {
                                api.moveClient(c.getId(), 2);
                                move.remove(c.getId());
                            }

                        } else if(move.get(c.getId()) == "software"  && moveable.get(c.getId()) == true) {
                            if(c.getChannelId() == 18) {
                                api.moveClient(c.getId(), 2);
                                move.remove(c.getId());
                            }

                        }
                    }
                }
            }

            @Override
            public void onServerEdit(ServerEditedEvent arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onPrivilegeKeyUsed(PrivilegeKeyUsedEvent arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onClientMoved(ClientMovedEvent event) {
            	ClientMovedEvent e = event;
            	if(move.containsKey(e.getClientId())) {
                    move.remove(e.getClientId());

                }
                if(moveable.containsKey(e.getClientId())) {
                    moveable.remove(e.getClientId());

                }


                for(Client client : api.getClients()) {
                    if(client.getId() == e.getClientId()) {
                        Client c = client;

                        if(e.getTargetChannelId() == 18) {
                            //software
                            move.put(e.getClientId(),"software");
                            Timer t = new Timer();
                            t.schedule(new TimerTask() {
                                @Override
                                public void run() {

                                    if(c.getChannelId() == 18 && move.get(e.getClientId()) == "software") {
                                        api.sendPrivateMessage(e.getClientId(), "Zur Zeit sind unsere Softwarehelper in ein Gespräch verwickelt. Bitte warte hier im Channel, bis dir geholfen wird, oder stelle deine Frage einfach im Tech Talk." +
                                                "\nUm direkt zum Tech Talk 1 zu gelangen, kannst du !move in den Chat schreiben.");
                                        moveable.put(e.getClientId(), true);
                                    }

                                }
                            }, 300000);

                        } else if(e.getTargetChannelId() == 17) {
                            //hardware
                            Timer t = new Timer();
                            move.put(e.getClientId(),"hardware");

                            t.schedule(new TimerTask() {
                                @Override
                                public void run() {

                                    if(c.getChannelId() == 17 && move.get(e.getClientId()) == "hardware") {
                                        api.sendPrivateMessage(e.getClientId(), "Zur Zeit sind unsere Hardwarehelper in ein Gespräch verwickelt. Bitte warte hier im Channel, bis dir geholfen wird, oder stelle deine Frage einfach im Tech Talk. "
                                                + "\nUm direkt zum Tech Talk 1 zu gelangen, kannst du !move in den Chat schreiben.");
                                        moveable.put(e.getClientId(), true);
                                    }

                                }
                            }, 300000);
                        }
                    }
                }
                
                check();

            }

            @Override
            public void onClientLeave(ClientLeaveEvent event) {
                
                check();                

            }

            @Override
            public void onClientJoin(ClientJoinEvent event) {
            	
                check();                

            }

            @Override
            public void onChannelPasswordChanged(ChannelPasswordChangedEvent arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onChannelMoved(ChannelMovedEvent arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onChannelEdit(ChannelEditedEvent arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onChannelDescriptionChanged(ChannelDescriptionEditedEvent arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onChannelDeleted(ChannelDeletedEvent arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onChannelCreate(ChannelCreateEvent arg0) {
                // TODO Auto-generated method stub

            }
        });

    }
    
    public static void check() {
    	int supporter = 0;
        for (Client client : api.getClients()) {
            if(client.isInServerGroup(11)) {
            	if(client.getChannelId() != 147 && client.getChannelId() != 146 &&client.getChannelId() != 29) {
            		supporter++;
            	}
                
            } 
        }
        
        if(supporter == 0) {
            Map<ChannelProperty, String> property = new HashMap<ChannelProperty, String>();
            if(api.getChannelInfo(19).getName().equalsIgnoreCase("Support [Geöffnet]")) {
                property.put(ChannelProperty.CHANNEL_NAME, "Support [Geschlossen]");
                property.put(ChannelProperty.CHANNEL_MAXCLIENTS, "0");
                property.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "0");
                //int i;
                Load.api.editChannel(19, property);
                property.clear();
            }
            Map<ChannelProperty, String> property1 = new HashMap<ChannelProperty, String>();
            if(api.getChannelInfo(20).getName().equalsIgnoreCase("Verifizierung [Geöffnet]")) {
                property1.put(ChannelProperty.CHANNEL_NAME, "Verifizierung [Geschlossen]");
                property1.put(ChannelProperty.CHANNEL_MAXCLIENTS, "0");
                property1.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "0");
                Load.api.editChannel(20, property1);
                property1.clear();
            }
        } else if(supporter > 0) {
        	Map<ChannelProperty, String> property = new HashMap<ChannelProperty, String>();
            if(api.getChannelInfo(19).getName().equalsIgnoreCase("Support [Geschlossen]")) {
                property.put(ChannelProperty.CHANNEL_NAME, "Support [Geöffnet]");
                property.put(ChannelProperty.CHANNEL_MAXCLIENTS, "20");
                property.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "20");
                //int i;
                Load.api.editChannel(19, property);
                property.clear();
            }
            Map<ChannelProperty, String> property1 = new HashMap<ChannelProperty, String>();
            if(api.getChannelInfo(20).getName().equalsIgnoreCase("Verifizierung [Geschlossen]")) {
                property1.put(ChannelProperty.CHANNEL_NAME, "Verifizierung [Geöffnet]");
                property1.put(ChannelProperty.CHANNEL_MAXCLIENTS, "20");
                property1.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "20");
                Load.api.editChannel(20, property1);
                property1.clear();
            }
        }
        
        int software = 0;
        for (Client client : api.getClients()) {
        	
            if(client.isInServerGroup(14)) {
            	if(client.getChannelId() != 147 && client.getChannelId() != 146 &&client.getChannelId() != 29) {
            		software++;
            	}
                
            } 
        }
        
        if(software == 0) {
            Map<ChannelProperty, String> property = new HashMap<ChannelProperty, String>();
            if(api.getChannelInfo(18).getName().equalsIgnoreCase("Softwarehelp [Geöffnet]")) {
                property.put(ChannelProperty.CHANNEL_NAME, "Softwarehelp [Geschlossen]");
                property.put(ChannelProperty.CHANNEL_MAXCLIENTS, "0");
                property.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "0");
                Load.api.editChannel(18, property);
                property.clear();
            }
        } else if(software > 0) {
        	
        	Map<ChannelProperty, String> property1 = new HashMap<ChannelProperty, String>();
            //if(api.getChannelInfo(18).getName().equalsIgnoreCase("Softwarehelp [Geschlossen]")) { 
            	
                property1.put(ChannelProperty.CHANNEL_NAME, "Softwarehelp [Geöffnet]");
                
                property1.put(ChannelProperty.CHANNEL_MAXCLIENTS, "20");
                
                property1.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "20");
                System.out.println("31");
                api.editChannel(18, property1);
                System.out.println("4");
                property1.clear();
            //}
        }
        
        int hardware = 0;
        for (Client client : api.getClients()) {
            if(client.isInServerGroup(15)) {
            	if(client.getChannelId() != 147 && client.getChannelId() != 146 &&client.getChannelId() != 29) {
            		hardware++;
            	}
                
            }
        }
        if(hardware == 0) {
            Map<ChannelProperty, String> property = new HashMap<ChannelProperty, String>();
            if(!api.getChannelInfo(17).getName().equalsIgnoreCase("Hardwarehelp [Geöffnet]")) {
                property.put(ChannelProperty.CHANNEL_NAME, "Hardwarehelp [Geschlossen]");
                property.put(ChannelProperty.CHANNEL_MAXCLIENTS, "0");
                property.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "0");
                Load.api.editChannel(17, property);
                property.clear();
            }
        } else if(hardware > 0) {
        	Map<ChannelProperty, String> property = new HashMap<ChannelProperty, String>();
            if(!api.getChannelInfo(17).getName().equalsIgnoreCase("Hardwarehelp [Geschlossen]")) {
                property.put(ChannelProperty.CHANNEL_NAME, "Hardwarehelp [Geöffnet]");
                property.put(ChannelProperty.CHANNEL_MAXCLIENTS, "20");
                property.put(ChannelProperty.CHANNEL_FLAG_MAXCLIENTS_UNLIMITED, "20");
                Load.api.editChannel(17, property);
                property.clear();
            }
        }
        
        
        System.out.println("----------------------------");
        System.out.println("Supporter: "+supporter);
        System.out.println("Hardware: "+hardware);
        System.out.println("software: "+software);
        System.out.println("----------------------------");
    }
 
}