package Load;

import java.util.Timer;
import java.util.TimerTask;

import com.github.theholywaffle.teamspeak3.api.event.ClientMovedEvent;
import com.github.theholywaffle.teamspeak3.api.wrapper.Client;

import Ts3querrybot.Load;

public class Poker {
	private ClientMovedEvent event = null;
	
	public Poker(ClientMovedEvent event) {
		event = event;
	}
	
	public void start() {
		
		int clientId = event.getClientId();
		if(event.getTargetChannelId() == 54965) {
			//Software
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				
				@Override
				public void run() {
					int i = 0;
					i++;					
					Client c = null;
					for(Client client : Load.api.getClients()) {
						if(event.getClientId() == client.getId()) {
							c = client;
						}
					}
					if(c.getChannelId() == event.getTargetChannelId() && i == 1) {
						Load.api.sendPrivateMessage(c.getId(), "Zur Zeit sind unsere Hardwarehelper in ein Gespr�ch verwickelt. Bitte warte hier im Channel, bis dir geholfen wird, oder stelle deine Frage einfach im Hardwaretalk. "
								+ "\nUm direkt zum Hardwaretalk 1 zu gelangen, kannst du !move in den Chat schreiben.");
						timer.cancel();
						Event.move.put(c.getId(), "softmove");
						System.out.println("softmove");
					}
					
				}
			}, 420000, 420000);
					
		} else if(event.getTargetChannelId() == 54966){
			//Hardware
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				
				@Override
				public void run() {
					int i = 0;
					i++;					
					Client c = null;
					for(Client client : Load.api.getClients()) {
						if(event.getClientId() == client.getId()) {
							c = client;
						}
					}
					if(c.getChannelId() == event.getTargetChannelId() && i == 1) {
						Load.api.sendPrivateMessage(c.getId(), "Zur Zeit sind unsere Softwarehelper in ein Gespr�ch verwickelt. Bitte warte hier im Channel, bis dir geholfen wird, oder stelle deine Frage einfach im Softwaretalk. "
								+ "\nUm direkt zum Softwaretalk 1 zu gelangen, kannst du !move in den Chat schreiben.");
						timer.cancel();
						Event.move.put(c.getId(), "hardmove");
						System.out.println("hardmove");
					}
					
				}
			}, 420000, 420000);		
											
		}
	}
	
}
